import * as React from 'react';
import { Text, View, Button, TouchableOpacity } from 'react-native';
import (Audio) from "expo-av";

class SoundButton extends React.Component {
   playSound = async () => {
     await Audio.Sound.CreateAsync(
      { uri: 'http://soundbible.com/mp3/Buzzer-SoundBible.com-188422102.mp3' },
      {ShouldPlay: true}
      );
  }

  render() {
    return (
      <touchableOpacity style={{
        marginLeft: 100, 
        borderWidth: 1,
        borderColor: 'rgba(0, 0, 0, 2)',
        alignItems: 'centre',
        justifyConstent: 'centre',
        width: 200,
        height: 200,
        backgroungColor: "red",
        backgroungRadius: 150;
      }}
      <"Text style" = {{
        FontWeight: 'bold',
        FontSize: '20', 
      }}
      <Text>PRESS ME</Text>
      </touchableOpacity>
     );
  }
}

export default class App extends React.Component {
  render() {
    return (
      <View style={{marginTop:200}}>
        <SoundButton />
      </View>
    );
  }
}


